function obtener_dato(id){
    location.href="/Html/LIBRO.php?id="+id;
}
function guardar_dato(id){
    location.href="/Html/categorias2.php?buscar="+id;
}